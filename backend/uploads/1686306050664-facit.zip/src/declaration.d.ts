declare module '*.png';
declare module '*.webp';
