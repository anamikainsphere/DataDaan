import { create } from '@storybook/theming';

export default create({
	base: 'dark',
	brandTitle: 'Facit',
	brandImage: 'https://facit-story.omtanke.studio/logo-light.svg',
});
